"""
Author: Daniella Bertoldi
Date: January 25, 2026
File Name: quote.py
Description: This program prints a quote that connects science and technology
and credits the original author.
"""

# This program outputs a quote related to science and technology

print("“The science of today is the technology of tomorrow.”")
print("— Edward Teller")
